Rachel Glomski
Assignment 3 for CSE 337

SortArray.java contains the ascending and descending sorting methods
SortArrayTest.java contains the tests for these methods
Both of these files are located in the src/sort directory

You can run the runTest.sh script to run the tests.
