To whom it may concern:

If you are running the file from an IDE, the .java file is under the /src directory, and is named HangmanTest.java.

If you're running from the command line, the compiled  files are located in the /bin directory.
I've also included an executable JAR file, if that's preferred.

-Rachel Glomski